
import global_variables as G
import arduino_board as B
import time

def check_move(solar_move, move_ready):
	#move gondola if move_ready and solar_move are true
	if solar_move == True and move_ready == True:
		G.moving = True
	elif solar_move == True and G.moving == True:
		G.moving = True
	elif solar_move == False and G.moving == True:
		G.moving = False
	elif solar_move == False and G.moving == False:
		G.moving = False

	return

#------------------------------#

#----------Move Gondola

# Directs the movement of the Gondola
# Checks location and redirects at ends of range
# Controls arduino_connect
# Updates Current Location
#
# 	Args in
# 		direction <int> -1, 0, 1
# 		position<int>
#------------------------------#

def move_gondola():
	
	

	if G.moving == True:
		if G.scanning == False:
			check_position() #Updates position and checks/reverses Direction
		if G.direction == -1:
			print('moving left, postion:',G.position )
			arduino_control('MOVELEFT')
			B.update_motor()
			time.sleep(.1)
			arduino_control('STOP')
			B.update_motor()
			time.sleep(.1)
		elif G.direction == 1:
			print('moving right, postion:',G.position)
			arduino_control('MOVERIGHT')
			B.update_motor()
			time.sleep(.1)
			arduino_control('STOP')
			B.update_motor()
			time.sleep(.1)
	elif G.moving == False:
		print('stopped')
		arduino_control('STOP')
		B.update_motor()
		

	return

#------------------------------#

#----------Check Position


#------------------------------#


def check_position():

	#if position = 0 or 99 reverse direction
	if G.position == 0 or G.position == 99:
		G.direction *= -1
	G.position += G.direction
	return

#------------------------------#

#----------Arduino Control


#------------------------------#
def arduino_control(command):

	#write analog out to ARDUINO_CONNECT Pin with control values
	#print(command)
	G.control_value = G.control[command]


	return

#------------------------------#

#----------Move to Position


#------------------------------#
def move_to_position():
	#only goes right to left
	G.direction = -1

	#loops until gondola position == solar average position
	for i in range(G.moves_to_solar_average):
		move_gondola()
		G.position += G.direction
