

#------------------------------#
import global_variables as G
import arduino_board as B
import numpy as np
#------------------------------#






#------------------------------#

#--------Check Solar-----------#

	# Args in 
	# 	-solar_left <float>
	# 	-solar_right <float>
	# 	-solar_average <float>
	# 	-SENSITIVITY <float>
	# Returns
	# 	solar_move <BOOL>
	# 	solar_disparity <INT> 'range:-1,1'

#------------------------------#

def check_solar():
	solar_disparity = 0
	solar_move = False
	try:
	#find solar difference
		solar_diff = G.solar_left - G.solar_right
		
		if abs(solar_diff) > G.sensitivity:
			solar_move = True
			if solar_diff > 0 : #if solar is higher on left side
				solar_disparity = 1
				print("left Brighter")
			else: #if solar is higher on right side
				solar_disparity = -1
				print('right Brighter')
		else:
			solar_move = False
			
		#Check if Left and Right are both below average
		if (G.solar_left <= G.solar_average - G.sensitivity/2 )and (G.solar_right <= G.solar_average-G.sensitivity/2 ):
			solar_disparity = 0
			solar_move = True
			G.mode_select = "scan"
		if solar_move == True and G.direction == 0:
			G.direction = solar_disparity * -1
	except:
		print('warming up')

	return solar_move



#------------------------------#

#--------Cooldown Solar----------#

# Counts cycles between gondola movements
# only runs in seeker mode

#------------------------------#


def cooldown_solar(solar_move, moving):
	move_ready = False
	if solar_move == True and moving == False:
		G.cooldown_timer += 1
		if G.cooldown_timer == G.cooldown_timer_limit:
			move_ready = True
			G.cooldown_timer = 0
	else:
		move_ready = False
	return move_ready




#------------------------------#

#------Reset Solar Array-------#


#------------------------------#
def reset_solar_array():
	G.solar_array_left = np.array([])
	G.solar_array_right = np.array([])
	G.solar_array_average = np.array([])
	





#------------------------------#

#------Add to Solar Array------#


#------------------------------#
def add_to_solar_array():
	G.solar_array_left=np.append(G.solar_array_left,[G.solar_left]) 
	G.solar_array_right=np.append(G.solar_array_right,[G.solar_right]) 
	G.solar_array_average = np.append(G.solar_array_average, [(G.solar_left+G.solar_right)/2])




#------------------------------#

#------Solar Array Control-----#


#------------------------------#


def solar_array_control():
	#find highest value in solar array returns tuple
	max_solar_position =  np.where(G.solar_array_average == np.amax(G.solar_array_average))
	
	#turns tuple into single value of index position on array (0-99) and sets global
	G.solar_average_position = max_solar_position[0][0]
	G.solar_average = np.average(G.solar_array_average)
	G.moves_to_solar_average = 99 - G.solar_average_position
