import numpy as np

global solar_array_left

global solar_array_right

global solar_array_average

global scanning
scanning =  False

global solar_average_position
solar_average_position = 0
global moves_to_solar_average
moves_to_solar_average = 0 

global position
position = 50
global direction
direction = 0
global control
control = {
	'MOVELEFT':(1,0),
	'STOP': (0,0),
	'MOVERIGHT':(0,1),
	'MOVETOSTART':(1,1)
	}
global control_value
control_value = (0,0)

global solar_left
solar_left = 0.0
global solar_right
solar_right = 0.0
global solar_average
solar_average = 0.0
global sensitivity
sensitivity = .2

global cooldown_timer
cooldown_timer = 0
global cooldown_timer_limit
cooldown_timer_limit = 10

global moving
moving = False


global move_ready
move_ready = False
global solar_move
solar_move = False