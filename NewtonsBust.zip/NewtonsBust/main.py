
import global_variables as G
import arduino_board as B
import time
import numpy as np
import matplotlib.pyplot as plt
from solar import check_solar, cooldown_solar, reset_solar_array, add_to_solar_array, solar_array_control
from movement import move_gondola, arduino_control, check_position, check_move, move_to_position



#------------------------------#

#----------Scan Mode

#------------------------------#


def scan_mode():
	

	#first cycle in scan
	if G.scanning == False:
		G.scanning = True
		G.moving = True
		#return to position 1
		arduino_control('MOVETOSTART')
		B.update_motor()#Activate move command
		G.position = 0
		time.sleep(3)

		#reset numpy arrays
		reset_solar_array()

		#set direction to the right
		G.direction = 1



	elif G.scanning == True and G.position != 99:
		B.update_solar() #Get solar values from board

		add_to_solar_array() #add solar values to the solar array

		print('solar AVG:',G.solar_array_average[G.position])

		#arduino_control('MOVERIGHT') #set next move command
		move_gondola()
		G.position += 1   #increase position

	elif G.scanning == True and G.position == 99:

		solar_array_control() #finds brightest spot. sets position and num of moves to get there 


		move_to_position() #moves gondola to brightest spot


		#end scan cycle
		G.moving = False
		G.scanning = False
		G.direction = 0
		G.mode_select = "seeker"
		time.sleep(3)

	
	return





#------------------------------#

#----------Seeker Mode

#------------------------------#

def seeker_mode():
	#gather solar data
	B.update_solar()
	#check solar difference set high_difference
	solar_move = check_solar()
	#check cooldown timer set move_ready	
	move_ready = cooldown_solar(solar_move, G.moving)
	
	check_move(solar_move, move_ready)
		
	move_gondola()

	print(f'solar_move: {solar_move}  --- move_ready: {move_ready} - {G.cooldown_timer} -- moving: {G.moving} -- Dir:{G.direction} -- POS: {G.position}')
	print('RIGHT:', G.solar_right,'LEFT:', G.solar_left)
	



#------------------------------#

#----------Main Loop

#

#------------------------------#

#Check run_mode and run
G.direction = 1
G.moving = True

	
	
#reset_solar_array()
#for i in range(100):
while True:	
	if G.mode_select == "scan":
		scan_mode()
	elif G.mode_select == "seeker":
		seeker_mode()


	#B.update_motor()
	#seeker_mode()
	#seeker_mode()
#	B.update_solar()
#	add_to_solar_array()
	print(f"Left: {G.solar_left}----Right: {G.solar_right}")
#	time.sleep(.1)
	#print('working')
	#time.sleep(1)



# x = np.arange(0,100)

# y1 = G.solar_array_left
# y2 = G.solar_array_right

# plt.plot(y1,y2)
# plt.xlim((0,1))
# plt.ylim((0,1))
# plt.savefig('Value comparisions.png')
# plt.show()