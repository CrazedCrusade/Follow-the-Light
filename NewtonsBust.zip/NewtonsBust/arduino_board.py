from pyfirmata2 import Arduino, INPUT, OUTPUT, PWM, util
import time
import global_variables as G

port = 'COM4'

board = Arduino(port)

#time.sleep(2)


SOLAR_CELL_L = board.get_pin('a:0:i')
SOLAR_CELL_L.enable_reporting()
SOLAR_CELL_R = board.get_pin('a:1:i')
ARDUINO_CONTROL_A = board.get_pin('d:9:o')
ARDUINO_CONTROL_B = board.get_pin('d:8:o')
time.sleep(2)



it = util.Iterator(board)
it.start()


def update():
	G.solar_left = SOLAR_CELL_L.read()
	G.solar_right = SOLAR_CELL_R.read() 


	# ARDUINO_CONTROL_A.write(0)
	# ARDUINO_CONTROL_B.write(1)
	# time.sleep(.25)
	# ARDUINO_CONTROL_A.write(1)
	# ARDUINO_CONTROL_B.write(0)
	time.sleep(.1)

	ARDUINO_CONTROL_A.write(G.control_value[0])
	ARDUINO_CONTROL_B.write(G.control_value[1])

	time.sleep(.1)
	
	# LED_GREEN.write(1)
	# LED_RED.write(1)
	# LED_BLUE.write(1)

def update_solar():
	G.solar_left = SOLAR_CELL_L.read()
	G.solar_right = SOLAR_CELL_R.read() * (.6/0.4) # the dirksen correctional coeffecient

def update_motor():
	ARDUINO_CONTROL_A.write(G.control_value[0])
	ARDUINO_CONTROL_B.write(G.control_value[1])
	#time.sleep(.2)